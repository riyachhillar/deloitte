package com.deloitte.library.model;

public class Books {
	private int bookId;
	private String bookName;
	private String author;
	private int price;
	
	public int getBookId() {
		return bookId;
	}




	public void setBookId(int bookId) {
		this.bookId = bookId;
	}

	public Books() {
		
		
	}

	public String getBookName() {
		return bookName;
	}
	public void setBookName(String bookName) {
		this.bookName = bookName;
	}
	public String getAuthor() {
		return author;
	}
	public void setAuthor(String author) {
		this.author = author;
	}
	public int getPrice() {
		return price;
	}
	public void setPrice(int price) {
		this.price = price;
	}

	@Override
	public String toString() {
		return "LibraryManagement [bookId=" + bookId + ", bookName=" + bookName + ", author=" + author + ", price="
				+ price + "]";
	}
	
	
}
