package com.deloitte.library.services;

import com.deloitte.library.model.Books;
import java.util.*;

public interface BooksInterface {
 public void insertBook(int bookId, String bookName, String author, int price);
public ArrayList<Books> display();
}
