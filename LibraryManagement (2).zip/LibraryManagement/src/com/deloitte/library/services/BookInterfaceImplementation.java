package com.deloitte.library.services;

import com.deloitte.library.dao.BooksDAO;
import com.deloitte.library.model.Books;
import java.util.*;

public class BookInterfaceImplementation implements BooksInterface {

	@Override
	public void insertBook(int bookId,String bookName, String author, int price) {
		// TODO Auto-generated method stub

		Books obj = new Books();
		obj.setBookId(bookId);
		obj.setBookName(bookName);
		obj.setAuthor(author);
		obj.setPrice(price);
	BooksDAO.addBook(obj);
	}
	
	
	
	public ArrayList<Books> display() {
		return(BooksDAO.displayBooks());
	}
	

}
