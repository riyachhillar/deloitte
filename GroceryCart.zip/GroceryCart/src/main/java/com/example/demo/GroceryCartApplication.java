package com.example.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class GroceryCartApplication {

	public static void main(String[] args) {
		SpringApplication.run(GroceryCartApplication.class, args);
	}

}
