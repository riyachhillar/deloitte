package com.deloitte.grocery.main;

import java.util.*;
import java.sql.*;

import com.deloitte.grocery.model.UserDetails;
import com.deloitte.grocery.services.GroceryImplementation;




public class DemoGrocery {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		GroceryImplementation mainObj = new GroceryImplementation();
		
		Scanner sc = new Scanner(System.in);
		 ArrayList<UserDetails> users = new ArrayList<UserDetails>();
		
			while (true) {
				System.out.println("Please select an option");
				System.out.println("option 1 to add new user ");
				System.out.println("option 2 to display users");
				System.out.println("option 3 to login");
				System.out.println("option 4 exit");
				System.out.println("");
				
				String option = sc.next();
			

				switch (option) {
				case "1":
					String name, email, password, username ;
					int user_id, phNo ;
				
               System.out.println("Enter user details");
           	System.out.println("Enter user id");
          user_id = Integer.parseInt(sc.next());
				System.out.println("Enter name");
				name =sc.next();
				System.out.println("Enter username");
				username = sc.next();
				System.out.println("Enter email");
				email = sc.next();
				System.out.println("Enter password");
				password = sc.next();
				System.out.println("Enter phone number");
				phNo = Integer.parseInt(sc.next());
				
				mainObj.addUsers(user_id, name, email, phNo, username, password);
             
				break;
				
				case "2" : 
					System.out.println("Displaying the database ");
				ArrayList<UserDetails> arr = new ArrayList<UserDetails>	();
				arr= mainObj.display();
				for(UserDetails d : arr)
				System.out.println(d);
				
					break;
				
				case "3" :
					
					System.out.println("LOGIN ");
					System.out.print("Enter username :  ");
					String userName = sc.next();
					System.out.print("");
					System.out.print("Enter password :  ");
					String pass = sc.next();
					System.out.print("");
					boolean result = mainObj.loginUser(userName, pass);
					if(result==true)
						System.out.println("Login Successful!");
					else
						System.out.println("User doesn't exist");
					
					
					
					
				break;
				
				
				
				
				case "4" :
					System.out.println("Application ended");
					System.exit(0);
					break;
				}

	}

}
}
