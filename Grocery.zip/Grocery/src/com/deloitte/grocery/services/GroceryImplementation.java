package com.deloitte.grocery.services;

import java.util.ArrayList;

import com.deloitte.grocery.dao.GroceryDAO;
import com.deloitte.grocery.model.UserDetails;

public class GroceryImplementation implements GroceryInterface {
	

	public void addUsers(int userId,String name, String email, int phno,
			String username, String password) {
		// TODO Auto-generated method stub
		
		UserDetails object = new UserDetails();
        object.setUserId(userId);
        object.setName(name);
        object.setEmail(email);
        object.setPhNo(phno);
        object.setUsername(username);
        object.setPassword(password);
        GroceryDAO.addUser(object);
	}
	
	
	
	public ArrayList<UserDetails> display() {
		return(GroceryDAO.displayUsers());
	}



	@Override
	public boolean loginUser(String username, String password) {
		// TODO Auto-generated method stub
		return GroceryDAO.userLogin(username, password);
	}

}
