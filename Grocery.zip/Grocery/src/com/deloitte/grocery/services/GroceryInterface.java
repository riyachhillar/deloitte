package com.deloitte.grocery.services;

import java.util.ArrayList;

import com.deloitte.grocery.model.UserDetails;

public interface GroceryInterface {

	void addUsers(int userId, String name, String email, int phno, String username, String password);
	 ArrayList<UserDetails> display();
	 boolean loginUser(String username, String password);
}
